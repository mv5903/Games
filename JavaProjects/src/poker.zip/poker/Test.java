package poker;


public class Test {
	public static void main(String[] args)  {
		
		int x = 5;
		int y = 7;
		
		System.out.println(x == 5 & y == 7);
		
	}
	



}
