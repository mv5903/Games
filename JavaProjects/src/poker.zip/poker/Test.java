package poker;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.nio.file.FileSystems;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.text.DefaultCaret;

public class Test extends JFrame {
	public static void main(String[] args) {
		new Test();
	}
	
	public Test() {
		build();
	}
	
	JTextArea taMessages, cardView, centerView;
	JTextField tfInput;
	JButton btnSend, btnExit;
	DeckOfCards dc = new DeckOfCards();
	CenterHand c = new CenterHand(dc.getNextCard(), dc.getNextCard());
	Font font = new Font("Segoe UI Symbol", Font.PLAIN, 20);
	
	public void build() {
		setResizable(false);
		setLayout(new BorderLayout(0, 0));
		btnSend = new JButton("Send");
		btnExit = new JButton("Exit");
		btnSend.setBackground(Color.black);
		btnSend.setForeground(Color.yellow);
		btnExit.setBackground(Color.black);
		btnExit.setForeground(Color.red);
		taMessages = new JTextArea();
		taMessages.setBackground(Color.black);
		taMessages.setForeground(Color.white);
		cardView = new JTextArea();
		//Poker stuff
		cardView.setText("Your Hand:\n" + new Hand(dc.getNextCard(), dc.getNextCard()).toString());
		centerView = new JTextArea();
		centerView.setText("Center:\n"+c.toString());
		cardView.setBackground(Color.black);
		centerView.setBackground(Color.black);
		cardView.setForeground(Color.white);
		centerView.setForeground(Color.white);
		cardView.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.white), BorderFactory.createEmptyBorder(4, 4, 4, 4)));
		centerView.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.white), BorderFactory.createEmptyBorder(4, 4, 4, 4)));
		taMessages.setRows(20);
		taMessages.setOpaque(true);
		taMessages.setColumns(52);
		taMessages.setEditable(false);
		taMessages.setFont(font);
		String str = "This is a test message.";
		taMessages.setText(str);
		taMessages.setWrapStyleWord(true);
		taMessages.setLineWrap(true);
		taMessages.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		tfInput = new JTextField(50);
		tfInput.setEditable(false);
		tfInput.setBackground(Color.LIGHT_GRAY);
		tfInput.setText("User input disabled.");
		tfInput.setPreferredSize(new Dimension(300, 35));
		tfInput.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, Color.white));
		btnSend.setPreferredSize(new Dimension(80, 35));
		btnSend.setBorder(BorderFactory.createMatteBorder(3, 3, 3, 3, Color.cyan));
		btnExit.setBorder(BorderFactory.createMatteBorder(3, 3, 3, 3, Color.cyan));
		btnExit.setPreferredSize(new Dimension(80, 35));
		JScrollPane sp = new JScrollPane(taMessages, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		add(sp, "Center");
		setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);
		JPanel tp = new JPanel(new FlowLayout());
		tp.add(taMessages);
		tp.setBorder(BorderFactory.createMatteBorder(10, 10, 10, 10, Color.blue));
		JPanel bp = new JPanel(new FlowLayout());
		DefaultCaret caret = (DefaultCaret) taMessages.getCaret();
		caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
		bp.add(cardView);
		bp.add(centerView);
		bp.add(tfInput);
		bp.add(btnSend);
		bp.add(btnExit);
		bp.setBackground(Color.black);
		bp.setBorder(BorderFactory.createMatteBorder(5, 5, 5, 5, Color.black));
		add(tp, "North");
		add(bp, "South");
		setVisible(true);
		setTitle("Poker Game");
		ImageIcon img = new ImageIcon(FileSystems.getDefault().getPath("").toAbsolutePath() + "\\src\\poker\\images\\icon.png");
		setIconImage(img.getImage());
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent windowEvent) {
				System.exit(0);
			}
		});
		btnExit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.exit(0);
			}
			
		});
		setFont(font);
		//
		setMinimumSize(new Dimension(800, 600));
		pack();
		tfInput.requestFocusInWindow();
		for (int i = 0; i < 3; i++) {
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {}
			c.dealNextCard(dc.getNextCard());
			centerView.setText("Center:\n" + c.toString());
		}
		
		
	}
	
	
}
