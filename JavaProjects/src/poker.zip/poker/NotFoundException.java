package poker;

public class NotFoundException extends Exception {
	public NotFoundException (String errorMessage) {
		super("Error Message");
	}

}
